#!/bin/bash

myhost=$(/usr/local/icinga/bin/get_icinganame)
service=endit-tss-write
status=""
msg=""

if (systemctl -q is-active $service)
then
status="OK"
msg="$service is running!!!"
else
status="CRITICAL"
msg="$service is not running!!!"
systemctl start $service
fi

/usr/local/icinga/bin/send_service "$myhost" "endit-tss-write-status" "$status" "$msg"

#echo "/usr/local/icinga/bin/send_service $myhost endit-tss-status $status $msg"

